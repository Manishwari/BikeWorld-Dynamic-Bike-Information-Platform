
function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;


    const storedUser = localStorage.getItem(username);

    if (!storedUser) {
        alert("User not found. Please register first.");
        return;
    }

    const user = JSON.parse(storedUser);


    if (user.password === password) {
        alert("Login successful!");
        window.location.href = "models.html"; 
    } else {
        alert("Incorrect password. Please try again.");
    }
}
