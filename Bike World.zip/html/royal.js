function toggleReadMore() {
    const moreInfo = document.getElementById("moreInfo");
    const readMoreBtn = document.getElementById("readMoreBtn");
  
    if (moreInfo.style.display === "none" || moreInfo.style.display === "") {
      moreInfo.style.display = "block";
      readMoreBtn.textContent = "Read Less";
    } else {
      moreInfo.style.display = "none";
      readMoreBtn.textContent = "Read More";
    }
  }