// formValidation.js
document.querySelector(".register-form").addEventListener("submit", function(e) {
    let password = document.getElementById("password").value;
    if (password.length < 6) {
        e.preventDefault();
        alert("Password must be at least 6 characters.");
    }
});
